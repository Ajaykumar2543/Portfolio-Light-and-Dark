setTimeout(function() {
    $('.about-info-inner').typed({
      strings: [
        "<span>Hi, I am  Abhi Ram</span> Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit eius officia ea ut vonsectetur adipisicing elit. Illo voluptatum iste, tempora rem obcaecati omnis delectus sunt, consequuntur, et ut quasi aperiam assumenda! <br><br> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ex beatae reprehenderit vero maiores dignissimos error vitae, optio inventore explicabo quia officiis magni delectus? Lorem ipsum dolor, sit amet consectetur"
      ],
      typeSpeed: 7,
      contentType: 'html'
    });
  }, 100);